better-douyin Windows portable
================================

解压后双击 better-douyin.exe 即可启动。

如果程序没有窗口或无法启动，请先安装 Microsoft Edge WebView2 Runtime：
https://developer.microsoft.com/microsoft-edge/webview2/
